/* PawCare front-end interactions. Demo data is not sent to a server. */
(function () {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  // Footer year and date minimums
  $("#year").textContent = new Date().getFullYear();
  const today = new Date();
  const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  ["#health-date", "#health-next", "#service-date"].forEach(sel => {
    const el = $(sel);
    if (el) el.min = localDate;
  });

  // Navigation closes on mobile after selection.
  $$(".nav-links a").forEach(link => link.addEventListener("click", () => {
    const toggle = $("#nav-toggle");
    if (toggle) toggle.checked = false;
  }));

  // Service cards prefill the request form.
  $$(".choose-service").forEach(button => button.addEventListener("click", () => {
    $("#service-type").value = button.dataset.service;
    $("#booking").scrollIntoView({ behavior: "smooth" });
  }));
  $$("[data-prefill-service]").forEach(link => link.addEventListener("click", () => {
    $("#service-type").value = link.dataset.prefillService;
  }));

  // Health tracker: localStorage persistence for this browser only.
  const HEALTH_KEY = "pawcare_health_records_v1";
  let healthRecords = [];
  try { healthRecords = JSON.parse(localStorage.getItem(HEALTH_KEY) || "[]"); } catch (_) { healthRecords = []; }
  if (!Array.isArray(healthRecords)) healthRecords = [];

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));
  }
  function saveHealth() {
    try { localStorage.setItem(HEALTH_KEY, JSON.stringify(healthRecords)); } catch (_) {}
    renderHealth();
  }
  function renderHealth() {
    const target = $("#health-records");
    if (!healthRecords.length) {
      target.innerHTML = '<p class="empty-state">No records yet. Add your first record using the form.</p>';
      return;
    }
    target.innerHTML = healthRecords.slice().reverse().map(record => `
      <article class="record-item">
        <div class="record-top"><strong>${escapeHTML(record.pet)} · ${escapeHTML(record.type)}</strong>
        <button class="delete-record" type="button" data-delete-health="${escapeHTML(record.id)}">Delete</button></div>
        <p>Date: ${escapeHTML(record.date || "Not specified")}</p>
        ${record.next ? `<span class="due">Next due: ${escapeHTML(record.next)}</span>` : ""}
        ${record.notes ? `<p>${escapeHTML(record.notes)}</p>` : ""}
      </article>`).join("");
  }
  $("#health-form").addEventListener("submit", event => {
    event.preventDefault();
    healthRecords.push({
      id: String(Date.now()) + Math.random().toString(16).slice(2),
      pet: $("#health-pet").value.trim(),
      type: $("#health-type").value,
      date: $("#health-date").value,
      next: $("#health-next").value,
      notes: $("#health-notes").value.trim()
    });
    saveHealth();
    event.target.reset();
    $("#health-date").min = localDate;
    $("#health-next").min = localDate;
    $("#health-records").scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
  $("#health-records").addEventListener("click", event => {
    const button = event.target.closest("[data-delete-health]");
    if (!button) return;
    healthRecords = healthRecords.filter(record => record.id !== button.dataset.deleteHealth);
    saveHealth();
  });
  $("#clear-health").addEventListener("click", () => {
    if (healthRecords.length && confirm("Delete all health records saved in this browser?")) {
      healthRecords = [];
      saveHealth();
    }
  });
  renderHealth();

  // Nutrition planner builds a user-editable routine, not medical dietary advice.
  $("#nutrition-form").addEventListener("submit", event => {
    event.preventDefault();
    const pet = $("#nutrition-pet").value.trim();
    const species = $("#nutrition-species").value;
    const food = $("#nutrition-food").value.trim();
    const meals = $("#nutrition-meals").value;
    const firstTime = $("#nutrition-time").value || "08:00";
    const numericMeals = Number(meals);
    const result = $("#nutrition-result");
    let schedule = [];
    if (Number.isInteger(numericMeals) && numericMeals > 0) {
      const [hours, minutes] = firstTime.split(":").map(Number);
      const start = hours * 60 + minutes;
      const gap = numericMeals > 1 ? Math.floor(12 * 60 / (numericMeals - 1)) : 0;
      schedule = Array.from({ length: numericMeals }, (_, i) => {
        const total = (start + i * gap) % (24 * 60);
        return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
      });
    } else {
      schedule = ["Follow a species-specific schedule advised by a qualified professional"];
    }
    result.innerHTML = `<div class="result-illustration">🥣</div><h4>${escapeHTML(pet)}'s feeding routine</h4>
      <p><b>Pet type:</b> ${escapeHTML(species)}</p><p><b>Food notes:</b> ${escapeHTML(food)}</p>
      <p><b>Planned feeding times:</b></p><ul>${schedule.map(time => `<li>${escapeHTML(time)}</li>`).join("")}</ul>
      <p>Confirm portions, ingredients and frequency with a veterinarian or species-appropriate expert.</p>`;
  });

  // Grooming checklist progress
  const groomChecks = $$(".groom-check");
  function updateGroomProgress() {
    const count = groomChecks.filter(input => input.checked).length;
    $("#groom-progress").style.width = `${count / groomChecks.length * 100}%`;
    $("#groom-progress-text").textContent = `${count} of ${groomChecks.length} completed`;
  }
  groomChecks.forEach(input => input.addEventListener("change", updateGroomProgress));
  $("#reset-grooming").addEventListener("click", () => {
    groomChecks.forEach(input => { input.checked = false; });
    updateGroomProgress();
  });
  updateGroomProgress();

  // Training plan: suggestions are deliberately general and adaptable.
  const activitySuggestions = {
    "Positive basic training": [
      "Start with one simple cue or behaviour.",
      "Reward small successes immediately with praise or an appropriate reward.",
      "End on a calm, successful moment."
    ],
    "Play and enrichment": [
      "Choose a safe, species-appropriate toy or enrichment activity.",
      "Supervise play and remove damaged or unsafe items.",
      "Finish with water and a calm break as appropriate."
    ],
    "Walking / movement": [
      "Choose a safe environment and equipment appropriate for your pet.",
      "Let your pet set a comfortable pace; don't force activity.",
      "Stop if your pet appears tired, distressed or uncomfortable."
    ],
    "Calm handling practice": [
      "Begin in a quiet, familiar space.",
      "Keep handling brief and reward relaxed behaviour.",
      "Pause or stop if your pet shows fear or stress."
    ],
    "Foraging / problem-solving": [
      "Use a safe activity designed for your pet's species.",
      "Make the first challenge easy and supervise throughout.",
      "Avoid small parts or foods that could be unsafe for your pet."
    ]
  };
  $("#training-form").addEventListener("submit", event => {
    event.preventDefault();
    const pet = $("#training-pet").value.trim();
    const type = $("#training-type").value;
    const goal = $("#training-goal").value;
    const duration = $("#training-duration").value;
    const steps = activitySuggestions[goal] || [];
    $("#training-result").innerHTML = `<div class="result-illustration">🎾</div><h4>${escapeHTML(pet)}'s ${escapeHTML(duration)} session</h4>
      <p><b>Pet:</b> ${escapeHTML(type)} · <b>Goal:</b> ${escapeHTML(goal)}</p>
      <ul>${steps.map(step => `<li>${escapeHTML(step)}</li>`).join("")}</ul>
      <p>Adapt this idea to your pet's age, health, species and comfort. This is a general activity suggestion, not professional behavioural advice.</p>`;
  });

  // Adoption enquiry checklist
  $("#adoption-enquiry").addEventListener("submit", event => {
    event.preventDefault();
    const name = $("#adopt-name").value.trim() || "your household";
    const animal = $("#adopt-animal").value;
    const questions = $("#adopt-questions").value.trim();
    $("#adoption-result").textContent =
      `Checklist prepared for ${name}: ask the shelter about ${animal.toLowerCase()} health history, care needs, adoption requirements and follow-up support.` +
      (questions ? ` Your notes: ${questions}` : "");
  });

  // Product demo store and cart
  const products = [
    {id:1,name:"Everyday Pet Food",category:"Food",price:499,icon:"🥣",desc:"Sample food listing. Choose a diet appropriate for your pet."},
    {id:2,name:"Treat Time Bites",category:"Food",price:199,icon:"🦴",desc:"Demo treat listing. Check ingredients and suitability first."},
    {id:3,name:"Play Ball",category:"Toys",price:149,icon:"🎾",desc:"A sample play item. Choose a size and material suitable for your pet."},
    {id:4,name:"Comfort Plush Toy",category:"Toys",price:299,icon:"🧸",desc:"Demo toy listing. Supervise use and replace damaged toys."},
    {id:5,name:"Pet T-shirt",category:"Clothing",price:349,icon:"👕",desc:"Sample clothing listing. Comfort and fit matter more than style."},
    {id:6,name:"Cozy Pet Bandana",category:"Clothing",price:129,icon:"🧣",desc:"Demo accessory. Avoid anything restrictive or unsafe."},
    {id:7,name:"Gentle Grooming Brush",category:"Hygiene",price:249,icon:"🪮",desc:"Sample grooming item. Select a tool designed for your pet."},
    {id:8,name:"Pet Care Shampoo",category:"Hygiene",price:299,icon:"🧴",desc:"Demo product only. Use species-appropriate products."},
    {id:9,name:"Walking Lead",category:"Accessories",price:399,icon:"🦮",desc:"Sample walking accessory. Correct sizing and secure fit are essential."},
    {id:10,name:"Food Bowl",category:"Accessories",price:179,icon:"🥣",desc:"Demo bowl listing. Pick an appropriate size and easy-clean material."},
    {id:11,name:"Soft Pet Bed",category:"Accessories",price:899,icon:"🛏️",desc:"Sample comfort item. Match the size and habitat needs."},
    {id:12,name:"Travel Carrier",category:"Accessories",price:1299,icon:"🧺",desc:"Demo carrier listing. Choose a secure, species-appropriate carrier."}
  ];
  let activeCategory = "All";
  const cart = new Map();
  const money = amount => "₹" + amount.toLocaleString("en-IN");
  function renderProducts() {
    const shown = activeCategory === "All" ? products : products.filter(p => p.category === activeCategory);
    $("#product-grid").innerHTML = shown.map(p => `<article class="product-card">
      <div class="product-art" aria-hidden="true">${p.icon}</div><div class="product-info">
      <span class="product-category">${escapeHTML(p.category)}</span><h3>${escapeHTML(p.name)}</h3>
      <p>${escapeHTML(p.desc)}</p><div class="product-bottom"><strong class="product-price">${money(p.price)}</strong>
      <button class="add-cart" type="button" data-add-product="${p.id}">Add to cart +</button></div></div></article>`).join("");
  }
  function renderCart() {
    const lines = Array.from(cart.entries()).map(([id, qty]) => ({product:products.find(p => p.id === id), qty})).filter(x => x.product);
    const count = lines.reduce((sum, line) => sum + line.qty, 0);
    const total = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
    $("#cart-count").textContent = count;
    $("#cart-total").textContent = money(total);
    $("#cart-items").innerHTML = lines.length ? lines.map(line => `<div class="cart-line"><div><b>${escapeHTML(line.product.name)}</b><br><span>${money(line.product.price)} × ${line.qty}</span></div><div><b>${money(line.product.price * line.qty)}</b> <button class="delete-record" data-remove-product="${line.product.id}" type="button" aria-label="Remove one ${escapeHTML(line.product.name)}">−</button></div></div>`).join("") : '<p class="empty-state">Your cart is empty. Add a demo product above.</p>';
  }
  $$(".filter-btn").forEach(button => button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    $$(".filter-btn").forEach(b => b.classList.toggle("active", b === button));
    renderProducts();
  }));
  $("#product-grid").addEventListener("click", event => {
    const button = event.target.closest("[data-add-product]");
    if (!button) return;
    const id = Number(button.dataset.addProduct);
    cart.set(id, (cart.get(id) || 0) + 1);
    renderCart();
    $("#cart-message").textContent = "Added to your demo cart. No order or payment has been made.";
  });
  $("#cart-items").addEventListener("click", event => {
    const button = event.target.closest("[data-remove-product]");
    if (!button) return;
    const id = Number(button.dataset.removeProduct);
    const qty = cart.get(id) || 0;
    if (qty <= 1) cart.delete(id); else cart.set(id, qty - 1);
    renderCart();
  });
  $("#clear-cart").addEventListener("click", () => {
    cart.clear(); renderCart();
    $("#cart-message").textContent = "Demo cart cleared.";
  });
  $("#checkout-demo").addEventListener("click", () => {
    $("#cart-message").textContent = cart.size
      ? "This is a demo only. Checkout, payments and real orders are not connected."
      : "Your cart is empty. Add a demo product first.";
  });
  renderProducts();
  renderCart();

  // Booking form checks inputs and gives a clear demo message.
  $("#booking-form").addEventListener("submit", event => {
    event.preventDefault();
    const date = $("#service-date").value;
    if (date && date < localDate) {
      $("#booking-result").textContent = "Please choose today or a future date.";
      $("#service-date").focus();
      return;
    }
    const name = $("#owner-name").value.trim();
    const pet = $("#pet-name").value.trim();
    const service = $("#service-type").value;
    $("#booking-result").textContent =
      `Details checked for ${name} and ${pet}: ${service}. This demo has not sent a request or confirmed an appointment. A backend or booking service is needed to submit it.`;
  });
})();
